package com.silenttiers.client.mixin;

import com.silenttiers.client.api.TierAPI;
import com.silenttiers.client.api.TierData;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererMixin {

    @ModifyArg(
        method = "renderLabelIfPresent(Lnet/minecraft/client/network/AbstractClientPlayerEntity;Lnet/minecraft/text/Text;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;IF)V",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/render/entity/LivingEntityRenderer;renderLabelIfPresent(Lnet/minecraft/entity/Entity;Lnet/minecraft/text/Text;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;IF)V"
        ),
        index = 1
    )
    private Text silenttiers_modifyNameTag(Text original) {
        String playerName = original.getString();

        // Fetch async
        TierAPI.fetchTierAsync(playerName);
        TierData data = TierAPI.getTier(playerName);

        if (data == null || !data.found || data.tier.equals("Unranked")) {
            return original;
        }

        // Build: "◆ HT5 | playerName | LT3 ◆"
        int color = data.getTierColor();

        MutableText tierText = Text.empty();

        // Crystal icon + tier before name
        tierText.append(Text.literal("◆ ").setStyle(Style.EMPTY.withColor(0xCC0000)));
        tierText.append(Text.literal(data.getShortTier()).setStyle(Style.EMPTY.withColor(color).withBold(true)));
        tierText.append(Text.literal(" | ").setStyle(Style.EMPTY.withColor(0x888888)));

        // Player name
        tierText.append(Text.literal(playerName).setStyle(Style.EMPTY.withColor(0xFFFFFF)));

        // Peak tier after name (if different)
        if (data.peakTier != null && !data.peakTier.equals(data.tier) && !data.peakTier.equals("Unranked")) {
            tierText.append(Text.literal(" | ").setStyle(Style.EMPTY.withColor(0x888888)));
            tierText.append(Text.literal(data.peakTier).setStyle(Style.EMPTY.withColor(0xAAAAAA)));
            tierText.append(Text.literal(" ◆").setStyle(Style.EMPTY.withColor(0xCC0000)));
        } else {
            tierText.append(Text.literal(" ◆").setStyle(Style.EMPTY.withColor(0xCC0000)));
        }

        return tierText;
    }
}
