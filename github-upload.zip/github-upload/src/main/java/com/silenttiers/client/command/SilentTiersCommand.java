package com.silenttiers.client.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.silenttiers.client.api.TierAPI;
import com.silenttiers.client.api.TierData;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.util.Formatting;

public class SilentTiersCommand {

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        dispatcher.register(
            ClientCommandManager.literal("silenttiers")
                .then(ClientCommandManager.argument("name", StringArgumentType.word())
                    .executes(ctx -> {
                        String name = StringArgumentType.getString(ctx, "name");
                        lookupPlayer(ctx.getSource(), name);
                        return 1;
                    })
                )
                .executes(ctx -> {
                    ctx.getSource().sendFeedback(buildHelpMessage());
                    return 1;
                })
        );

        // Short alias
        dispatcher.register(
            ClientCommandManager.literal("st")
                .then(ClientCommandManager.argument("name", StringArgumentType.word())
                    .executes(ctx -> {
                        String name = StringArgumentType.getString(ctx, "name");
                        lookupPlayer(ctx.getSource(), name);
                        return 1;
                    })
                )
        );
    }

    private static void lookupPlayer(FabricClientCommandSource source, String name) {
        source.sendFeedback(Text.literal("§8[§cSilent Tiers§8] §7Looking up §f" + name + "§7..."));

        // Fetch async
        TierAPI.clearCache(name);
        TierAPI.fetchTierAsync(name);

        // Check after a short delay
        new Thread(() -> {
            try {
                Thread.sleep(2000); // Wait for API response
            } catch (InterruptedException ignored) {}

            TierData data = TierAPI.getTier(name);

            if (data == null || !data.found) {
                source.sendFeedback(buildNotFoundMessage(name));
                return;
            }

            source.sendFeedback(buildProfileMessage(data));
        }).start();
    }

    private static Text buildProfileMessage(TierData data) {
        int tierColor = data.getTierColor();
        String line = "§8§m                                              ";

        MutableText msg = Text.empty();

        // Header
        msg.append(Text.literal("\n"));
        msg.append(Text.literal(line + "\n"));
        msg.append(Text.literal("  ").append(
            Text.literal("◆ Silent Tiers").setStyle(Style.EMPTY.withColor(0xCC0000).withBold(true))
        ).append(Text.literal("\n")));
        msg.append(Text.literal(line + "\n"));

        // Player name
        msg.append(Text.literal("\n"));
        msg.append(Text.literal("  §7Player: §f" + data.ign + "\n"));

        // Current tier with color
        msg.append(Text.literal("  §7Tier: "));
        msg.append(Text.literal("◆ ").setStyle(Style.EMPTY.withColor(0xCC0000)));
        msg.append(Text.literal(data.getDisplayTier()).setStyle(Style.EMPTY.withColor(tierColor).withBold(true)));
        msg.append(Text.literal(" §8(" + data.getShortTier() + ")\n"));

        // Peak tier
        if (data.peakTier != null && !data.peakTier.equals("Unranked")) {
            msg.append(Text.literal("  §7Peak: §6" + data.peakTier + "\n"));
        }

        // Previous tier
        if (data.previousTier != null && !data.previousTier.equals("Unranked")) {
            msg.append(Text.literal("  §7Previous: §e" + data.previousTier + "\n"));
        }

        // Region
        msg.append(Text.literal("  §7Region: §b" + data.region + "\n"));

        // Tester
        if (data.tester != null && !data.tester.equals("Unknown")) {
            msg.append(Text.literal("  §7Tester: §d" + data.tester + "\n"));
        }

        // Footer
        msg.append(Text.literal("\n"));
        msg.append(Text.literal(line + "\n"));

        // NameMC link
        msg.append(Text.literal("  ").append(
            Text.literal("§7[§fNameMC§7]").setStyle(
                Style.EMPTY
                    .withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, "https://namemc.com/profile/" + data.ign))
                    .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Text.literal("§7Click to open NameMC")))
            )
        ));
        msg.append(Text.literal("\n"));
        msg.append(Text.literal(line + "\n"));

        return msg;
    }

    private static Text buildNotFoundMessage(String name) {
        MutableText msg = Text.empty();
        msg.append(Text.literal("§8[§cSilent Tiers§8] §cPlayer §f" + name + " §cnot found.\n"));
        msg.append(Text.literal("§8[§cSilent Tiers§8] §7No data on Silent Tiers or MCTiers."));
        return msg;
    }

    private static Text buildHelpMessage() {
        MutableText msg = Text.empty();
        msg.append(Text.literal("\n§8§m                                              \n"));
        msg.append(Text.literal("  ").append(
            Text.literal("◆ Silent Tiers §7- Commands").setStyle(Style.EMPTY.withColor(0xCC0000).withBold(true))
        ).append(Text.literal("\n")));
        msg.append(Text.literal("§8§m                                              \n"));
        msg.append(Text.literal("\n"));
        msg.append(Text.literal("  §c/silenttiers <name> §8- §7Look up a player\n"));
        msg.append(Text.literal("  §c/st <name> §8- §7Short alias\n"));
        msg.append(Text.literal("\n"));
        msg.append(Text.literal("§8§m                                              \n"));
        return msg;
    }
}
